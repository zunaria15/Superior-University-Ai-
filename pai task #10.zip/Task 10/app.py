from flask import Flask, render_template, request, jsonify
import datetime
app = Flask(__name__)
faq_responses = {
    "room": "We have Deluxe, Standard, and Suite rooms available.",
    "price": "Prices start at $99 per night. Suites go up to $299.",
    "check in": "Check-in is at 2 PM. Early check-in may be available on request.",
    "check out": "Check-out time is 11 AM.",
    "location": "We are located at 123 Main Street, Downtown.",
    "facilities": "Facilities include free Wi-Fi, swimming pool, gym, and spa.",
    "book": "To book a room, please visit our booking page or call (123) 456-7890.",
    "contact": "You can contact us at (123) 456-7890 or hotel@example.com.",
    "cancel": "Cancellations can be made 24 hours before check-in with no charge."
}
def get_greeting():
    hour = datetime.datetime.now().hour
    if hour < 12:
        return "Good morning! "
    elif 12 <= hour < 18:
        return "Good afternoon! "
    else:
        return "Good evening! "
def get_bot_response(user_input):
    user_input = user_input.lower()
    response = ""

    if any(greet in user_input for greet in ["hello", "hi", "hey"]):
        response = f"{get_greeting()} How can I assist you regarding our hotel?"
    else:
        found = False
        for key in faq_responses:
            if key in user_input:
                response = faq_responses[key]
                found = True
                break
        if not found:
            if "book" in user_input or "reservation" in user_input:
                response = faq_responses["book"]
            else:
                response = "I'm not sure how to help with that. Try asking about rooms, prices, or facilities."

    return response

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["GET"])
def chatbot_response():
    user_text = request.args.get("msg")
    bot_reply = get_bot_response(user_text)
    return jsonify(bot_reply)

if __name__ == "__main__":
    app.run(debug=True)
