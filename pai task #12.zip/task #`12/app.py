from flask import Flask, render_template, request

app = Flask(__name__)

# 💬 Chatbot Q&A Pairs
qa_pairs = {
    "what is python": """ Python is a powerful and easy-to-learn programming language loved worldwide.

Example:
```python
print("Hello, Python World!")
```""",

    "what is ai": """ AI (Artificial Intelligence) is the simulation of human intelligence by machines.

Example:
```python
import random
print(random.choice(['Yes', 'No', 'Maybe']))
```""",

    "what is flask": """ Flask is a lightweight and flexible web framework for Python.

Example:
```python
from flask import Flask
app = Flask(__name__)

@app.route('/')
def home():
    return "Hello from Flask!"
```""",

    "what is html": """HTML (HyperText Markup Language) structures the content of web pages.

Example:
```html
<!DOCTYPE html>
<html>
<body>
    <h1>Hello HTML!</h1>
</body>
</html>
```""",

    "what is machine learning": """ Machine Learning enables computers to learn from data without being explicitly programmed.

Example:
```python
from sklearn.linear_model import LinearRegression
model = LinearRegression()
```""",

    "what is deep learning": """ Deep Learning is a subset of Machine Learning inspired by how human brains work.

Example:
```python
import tensorflow as tf
model = tf.keras.Sequential()
```""",

    "what is data science": """ Data Science is the art of analyzing data to find insights.

Example:
```python
import pandas as pd
df = pd.read_csv('data.csv')
print(df.head())
```""",

    "what is cloud computing": """ Cloud Computing allows access to data and applications over the internet.

Example:
```python
# You might upload a file to cloud storage
upload_to_cloud('file.txt')
```""",

    "what is github": """ GitHub is a platform for hosting and collaborating on code projects.

Example:
```bash
git init
git add .
git commit -m "First commit"
```""",

    "what is database": """ A Database stores organized information digitally.

Example:
```python
import sqlite3
conn = sqlite3.connect('example.db')
```""",

    "what is javascript": """ JavaScript makes websites interactive.

Example:
```javascript
alert('Hello JavaScript!');
```""",

    "what is api": """ API (Application Programming Interface) allows two applications to communicate.

Example:
```python
import requests
response = requests.get('https://api.example.com/data')
```""",

    "what is cybersecurity": """ Cybersecurity protects systems from digital attacks.

Example:
```python
password = input("Enter password: ")
if password == 'secret123':
    print("Access granted")
```""",

    "what is blockchain": """Blockchain is a decentralized ledger for secure transactions.

Example:
```python
block = {'index': 1, 'data': 'Transaction Data'}
```""",

    "what is robotics": """ Robotics deals with building machines that can act autonomously.

Example:
```python
class Robot:
    def move(self):
        print("Moving forward!")
```"""
}


# 🌟 Route for the homepage
@app.route('/', methods=['GET', 'POST'])
def home():
    answer = ''
    if request.method == 'POST':
        user_question = request.form['question'].lower()
        answer = qa_pairs.get(user_question, "❓ Sorry, I don't know the answer to that. Please ask something else!")
    return render_template('chat.html', answer=answer)

# 🚀 Run the app
if __name__ == '__main__':
    app.run(debug=True)
