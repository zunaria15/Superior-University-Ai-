# # test.py
# from PyMusic_Player import Music_Player_GUI

# ## Make sure all the .MP3 songs besides in the folder
# song_dir = {
#         'Happy': r'C:/Users/zunaira/Desktop/music assistent AI project/songs/Happy',
#            'Angry': r'C:/Users/zunaira/Desktop/music assistant AI project/songs/Angry',
#            'Disgust': r'C:/Users/zunaira/Desktop/music assistant AI project/songs/Digust',
#            'Fear': r'C:/Users/zunaira/Desktop/music assistant AI project/songs/Fear',
#            'Neutral': r'C:/Users/zunaira/Desktop/music assistant AI project/songs/Neutral',
#            'Sad': r'C:/Users/zunaira/Desktop/music assistant AI project/songs/Sad',
#            'Surprise': r'C:/Users/zunaira/Desktop/music assistant AI project/songs/Surprise'}

# # If you want to give the Icon, make sure you have downloaded proper .ICO file.
# icon = 'your.ico'
# Music_Player_GUI(song_dir,icon)

# test.py
from PyMusic_Player import Music_Player_GUI

## Make sure all the .MP3 songs besides in the folder
song_dir = 'path/of/songs_dir'

# If you want to give the Icon, make sure you have downloaded proper .ICO file.
icon = 'your.ico'
Music_Player_GUI(song_dir,icon)
