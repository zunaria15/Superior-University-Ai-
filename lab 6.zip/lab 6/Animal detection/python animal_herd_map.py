# import folium
# import geocoder
# import random
# import numpy as np
# from shapely.geometry import Point, Polygon

# g = geocoder.ip('me')
# if g.latlng:
#     user_lat, user_lon = g.latlng
# else:
#     print("⚠️ Warning: Could not retrieve location. Using default coordinates.")
#     user_lat, user_lon = 40.7128, -74.0060 

# m = folium.Map(location=[user_lat, user_lon], zoom_start=12, tiles="CartoDB dark_matter")

# safe_zone = Polygon([(user_lat - 0.05, user_lon - 0.05), 
#                      (user_lat + 0.05, user_lon - 0.05), 
#                      (user_lat + 0.05, user_lon + 0.05), 
#                      (user_lat - 0.05, user_lon + 0.05)])

# herd_positions = [(user_lat + random.uniform(-0.02, 0.02), user_lon + random.uniform(-0.02, 0.02)) for _ in range(10)]

# for i in range(len(herd_positions)):
#     lat, lon = herd_positions[i]
#     movement = np.random.uniform(-0.001, 0.001, size=(2,))
#     herd_positions[i] = (lat + movement[0], lon + movement[1])

# folium.Marker([user_lat, user_lon], popup="📍 You are here!", 
#               icon=folium.Icon(color="blue", icon="user", prefix="fa")).add_to(m)

# for lat, lon in herd_positions:
#     color = "green" if safe_zone.contains(Point(lat, lon)) else "red"
#     folium.Marker([lat, lon], popup=f"🚨 Animal Herd Detected!",
#                   icon=folium.Icon(color=color, icon="paw", prefix="fa")).add_to(m)

# folium.Polygon(locations=[(user_lat - 0.05, user_lon - 0.05), 
#                           (user_lat + 0.05, user_lon - 0.05), 
#                           (user_lat + 0.05, user_lon + 0.05), 
#                           (user_lat - 0.05, user_lon + 0.05)],
#                color="green", fill=True, fill_opacity=0.3, popup="Safe Zone").add_to(m)

# m.save("animal_detection_map.html")
# print("✅ Map generated: Open 'animal_detection_map.html' in your browser!")


import folium
import geocoder
import random
import requests
import numpy as np
from shapely.geometry import Point, Polygon

# Function to get location from IP
def get_ip_location():
    try:
        g = geocoder.ip('me')
        if g.latlng:
            return g.latlng
    except:
        pass

    # Alternative API (ipapi.co)
    try:
        response = requests.get("https://ipapi.co/json/")
        data = response.json()
        return data.get("latitude"), data.get("longitude")
    except:
        pass

    return None  # If all methods fail

# Get user location
location = get_ip_location()

if location:
    user_lat, user_lon = location
    print(f" Using detected location: {user_lat}, {user_lon}")
else:
    print(" Could not retrieve location. Using default coordinates (New York City).")
    user_lat, user_lon = 40.7128, -74.0060  # Default to NYC

# Create Map
m = folium.Map(location=[user_lat, user_lon], zoom_start=12, tiles="CartoDB dark_matter")

# Define Safe Zone
safe_zone = Polygon([(user_lat - 0.05, user_lon - 0.05), 
                     (user_lat + 0.05, user_lon - 0.05), 
                     (user_lat + 0.05, user_lon + 0.05), 
                     (user_lat - 0.05, user_lon + 0.05)])

# Generate Random Herd Positions
herd_positions = [(user_lat + random.uniform(-0.02, 0.02), user_lon + random.uniform(-0.02, 0.02)) for _ in range(10)]

# Simulate Small Movement for Herd
for i in range(len(herd_positions)):
    lat, lon = herd_positions[i]
    movement = np.random.uniform(-0.001, 0.001, size=(2,))
    herd_positions[i] = (lat + movement[0], lon + movement[1])

# Add Markers
folium.Marker([user_lat, user_lon], popup=" You are here!", 
              icon=folium.Icon(color="blue", icon="user", prefix="fa")).add_to(m)

for lat, lon in herd_positions:
    color = "green" if safe_zone.contains(Point(lat, lon)) else "red"
    folium.Marker([lat, lon], popup=f" Animal Herd Detected!",
                  icon=folium.Icon(color=color, icon="paw", prefix="fa")).add_to(m)

# Add Safe Zone Polygon
folium.Polygon(locations=[(user_lat - 0.05, user_lon - 0.05), 
                          (user_lat + 0.05, user_lon - 0.05), 
                          (user_lat + 0.05, user_lon + 0.05), 
                          (user_lat - 0.05, user_lon + 0.05)],
               color="green", fill=True, fill_opacity=0.3, popup="Safe Zone").add_to(m)

# Add JavaScript to Get Browser's GPS Location
gps_script = """
<script>
    navigator.geolocation.getCurrentPosition(
        function(position) {
            var lat = position.coords.latitude;
            var lon = position.coords.longitude;
            var user_marker = L.marker([lat, lon]).addTo(map);
            user_marker.bindPopup(" Your exact location (GPS)").openPopup();
            map.setView([lat, lon], 14);
        },
        function(error) {
            console.log("Error getting location: " + error.message);
        }
    );
</script>
"""

# Save Map
map_file = "animal_detection_map.html"
m.save(map_file)

# Inject JavaScript for GPS
with open(map_file, "a") as f:
    f.write(gps_script)

print(f" Map generated: Open '{map_file}' in your browser!")
